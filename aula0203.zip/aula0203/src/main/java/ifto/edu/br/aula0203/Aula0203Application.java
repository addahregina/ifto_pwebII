package ifto.edu.br.aula0203;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula0203Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula0203Application.class, args);
	}

}
