package ifto.edu.br.aula0203;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula0203ApplicationTests {

	@Test
	void contextLoads() {
	}

}
