package ifto.edu.br.aula1602.model.conexao;

import java.sql.Connection;

public interface ConexaoJDBC {
    public Connection criarConexao();
}
