CREATE TABLE tb_pessoa(
    id BIGINT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50)
);

INSERT INTO tb_pessoa (nome) VALUES('Melissa');
INSERT INTO tb_pessoa (nome) VALUES('Fagno');
INSERT INTO tb_pessoa (nome) VALUES('Antonella');
