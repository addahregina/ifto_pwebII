package ifto.edu.br.aula3003.controller;


import ifto.edu.br.aula3003.model.entity.Pessoa;
import ifto.edu.br.aula3003.model.repository.PessoaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Transactional
@Controller
@RequestMapping("pessoas")
public class PessoaController {
    @Autowired //dependencia
    PessoaRepository repository;

    public PessoaController() {
        repository = new PessoaRepository();
    }

    @GetMapping("/list")
    public String list(ModelMap model) {
        model.addAttribute("pessoas", repository.pessoas());
        return "/pessoa/list";
    }

    @GetMapping("/pessoaForm")
    public String pessoaForm(Pessoa pessoa) {
        return "/pessoa/pessoaForm";
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable("id") Long id, ModelMap model) {
        model.addAttribute("pessoa", repository.pessoa(id));
        return new ModelAndView("/pessoa/pessoaForm", model);
    }

    @PostMapping("/update")
    public ModelAndView update(Pessoa pessoa) {
        repository.update(pessoa);
        return new ModelAndView("redirect:/pessoas/list");
    }

    @GetMapping("/remove/{id}")
    public ModelAndView remove(@PathVariable("id") Long id) {
        repository.remove(id);
        return new ModelAndView("redirect:/pessoas/list");
    }

    @PostMapping("/save")
    public ModelAndView save(Pessoa pessoa) {
        repository.save(pessoa);
        return new ModelAndView("redirect:/pessoas/list");
    }
}
