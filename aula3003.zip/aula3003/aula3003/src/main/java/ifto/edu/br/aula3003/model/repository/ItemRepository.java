package ifto.edu.br.aula3003.model.repository;

import ifto.edu.br.aula3003.model.entity.Item;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
public class ItemRepository {
    @PersistenceContext
    private EntityManager em;

    public void save(Item itens) {
        em.persist(itens);
    }
    public Item item(Long id) {
        return em.find(Item.class, id);
    }
    public List<Item> itens() {
        Query query = em.createQuery("from Item");
        return query.getResultList();
    }
    public void remove(Long id) {
        Item p = em.find(Item.class, id);
        em.remove(p);
    }
    public void update(Item itens) {
        em.merge(itens);
    }
}
