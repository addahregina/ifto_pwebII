package ifto.edu.br.aula3003.controller;


import ifto.edu.br.aula3003.model.entity.Item;
import ifto.edu.br.aula3003.model.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Transactional
@Controller
@RequestMapping("itens")
public class ItemController {
    @Autowired //dependencia
    ItemRepository repository;

    public ItemController() {
        repository = new ItemRepository();
    }

    @GetMapping("/list")
    public String list(ModelMap model) {
        model.addAttribute("itens", repository.itens());
        return "/item/list";
    }

    @GetMapping("/form")
    public String form(Item item) {
        return "/item/form";
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable("id") Long id, ModelMap model) {
        model.addAttribute("item", repository.item(id));
        return new ModelAndView("/item/form", model);
    }

    @PostMapping("/update")
    public ModelAndView update(Item item) {
        repository.update(item);
        return new ModelAndView("redirect:/itens/list");
    }

    @GetMapping("/remove/{id}")
    public ModelAndView remove(@PathVariable("id") Long id) {
        repository.remove(id);
        return new ModelAndView("redirect:/itens/list");
    }

    @PostMapping("/save")
    public ModelAndView save(Item item) {
        repository.save(item);
        return new ModelAndView("redirect:/itens/list");
    }
}
