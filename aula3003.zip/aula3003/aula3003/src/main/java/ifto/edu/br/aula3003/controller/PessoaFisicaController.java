package ifto.edu.br.aula3003.controller;


import ifto.edu.br.aula3003.model.entity.PessoaFisica;
import ifto.edu.br.aula3003.model.repository.PessoaFisicaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Transactional
@Controller
@RequestMapping("pessoasFisicas")
public class PessoaFisicaController {
    @Autowired //dependencia
    PessoaFisicaRepository repository;

    public PessoaFisicaController() {
        repository = new PessoaFisicaRepository();
    }

    @GetMapping("/list")
    public String list(ModelMap model) {
        model.addAttribute("pessoasFisicas", repository.pessoasFisicas());
        return "/pessoaFisica/list";
    }

    @GetMapping("/form")
    public String form(PessoaFisica pessoaFisica) {
        return "/pessoaFisica/form";
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable("id") Long id, ModelMap model) {
        model.addAttribute("pessoaFisica", repository.pessoaFisica(id));
        return new ModelAndView("/pessoaFisica/form", model);
    }

    @PostMapping("/update")
    public ModelAndView update(PessoaFisica pessoaFisica) {
        repository.update(pessoaFisica);
        return new ModelAndView("redirect:/pessoasFisicas/list");
    }

    @GetMapping("/remove/{id}")
    public ModelAndView remove(@PathVariable("id") Long id) {
        repository.remove(id);
        return new ModelAndView("redirect:/pessoasFisicas/list");
    }

    @PostMapping("/save")
    public ModelAndView save(PessoaFisica pessoaFisica) {
        repository.save(pessoaFisica);
        return new ModelAndView("redirect:/pessoasFisicas/list");
    }
}
