package ifto.edu.br.aula3003.model.repository;

import ifto.edu.br.aula3003.model.entity.PessoaJuridica;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
public class PessoaJuridicaRepository {
    @PersistenceContext
    private EntityManager em;

    public void save(PessoaJuridica pessoaJuridica) {
        em.persist(pessoaJuridica);
    }
    public PessoaJuridica pessoaJuridica(Long id) {
        return em.find(PessoaJuridica.class, id);
    }
    public List<PessoaJuridica> pessoasJuridicas() {
        Query query = em.createQuery("from PessoaJuridica");
        return query.getResultList();
    }
    public void remove(Long id) {
        PessoaJuridica p = em.find(PessoaJuridica.class, id);
        em.remove(p);
    }
    public void update(PessoaJuridica pessoaJuridica) {
        em.merge(pessoaJuridica);
    }
}
