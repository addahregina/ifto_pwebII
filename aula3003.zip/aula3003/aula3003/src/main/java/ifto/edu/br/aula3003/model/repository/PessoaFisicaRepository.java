package ifto.edu.br.aula3003.model.repository;

import ifto.edu.br.aula3003.model.entity.PessoaFisica;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
public class PessoaFisicaRepository {
    @PersistenceContext
    private EntityManager em;

    public void save(PessoaFisica pessoaFisica) {
        em.persist(pessoaFisica);
    }
    public PessoaFisica pessoaFisica(Long id) {
        return em.find(PessoaFisica.class, id);
    }
    public List<PessoaFisica> pessoasFisicas() {
        Query query = em.createQuery("from PessoaFisica");
        return query.getResultList();
    }
    public void remove(Long id) {
        PessoaFisica p = em.find(PessoaFisica.class, id);
        em.remove(p);
    }
    public void update(PessoaFisica pessoaFisica) {
        em.merge(pessoaFisica);
    }
}
