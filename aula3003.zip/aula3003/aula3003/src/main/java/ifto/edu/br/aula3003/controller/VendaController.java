package ifto.edu.br.aula3003.controller;


import ifto.edu.br.aula3003.model.entity.Venda;
import ifto.edu.br.aula3003.model.repository.VendaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Transactional
@Controller
@RequestMapping("vendas")
public class VendaController {
    @Autowired //dependencia
    VendaRepository repository;

    public VendaController() {
        repository = new VendaRepository();
    }

    @GetMapping("/list")
    public String list(ModelMap model) {
        model.addAttribute("vendas", repository.vendas());
        return "/venda/list";
    }

    @GetMapping("/form")
    public String form(Venda venda) {
        return "/venda/form";
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable("id") Long id, ModelMap model) {
        model.addAttribute("venda", repository.venda(id));
        return new ModelAndView("/venda/form", model);
    }

    @PostMapping("/update")
    public ModelAndView update(Venda venda) {
        repository.update(venda);
        return new ModelAndView("redirect:/vendas/list");
    }

    @GetMapping("/remove/{id}")
    public ModelAndView remove(@PathVariable("id") Long id) {
        repository.remove(id);
        return new ModelAndView("redirect:/vendas/list");
    }

    @PostMapping("/save")
    public ModelAndView save(Venda venda) {
        repository.save(venda);
        return new ModelAndView("redirect:/vendas/list");
    }
}
