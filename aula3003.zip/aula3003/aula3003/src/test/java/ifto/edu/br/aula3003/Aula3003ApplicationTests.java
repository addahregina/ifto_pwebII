package ifto.edu.br.aula3003;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula3003ApplicationTests {

	@Test
	void contextLoads() {
	}

}
