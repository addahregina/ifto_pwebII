package ifto.edu.br.aula1602;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula1602ApplicationTests {

	@Test
	void contextLoads() {
	}

}
