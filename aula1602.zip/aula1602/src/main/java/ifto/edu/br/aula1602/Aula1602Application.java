package ifto.edu.br.aula1602;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula1602Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula1602Application.class, args);
	}

}
