package ifto.edu.br.aula1602.controller;

import ifto.edu.br.aula1602.model.dao.PessoaDAO;
import ifto.edu.br.aula1602.model.entity.Pessoa;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("pessoas")
public class PessoaController {

    PessoaDAO pessoaDAO;

     public PessoaController(){
         pessoaDAO = new PessoaDAO();
     }
    @GetMapping("/list")
    public String list(ModelMap model){
         model.addAttribute("pessoas", pessoaDAO.buscarPessoas());
         return "/pessoa/list";
    }

    @GetMapping("/form")
    public String form(Pessoa pessoa){
        return "/pessoa/form";
    }
    
}
