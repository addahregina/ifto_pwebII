CREATE TABLE tb_pessoa(
    id BIGINT NOT NULL,
    nome VARCHAR(50)
);

INSERT INTO tb_pessoa (id, nome) VALUES(1, 'Melissa');
INSERT INTO tb_pessoa (id, nome) VALUES(2, 'Fagno');
INSERT INTO tb_pessoa (id, nome) VALUES(3, 'Antonella');
