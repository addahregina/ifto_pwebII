package ifto.edu.br.aula0903;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula0903ApplicationTests {

	@Test
	void contextLoads() {
	}

}
