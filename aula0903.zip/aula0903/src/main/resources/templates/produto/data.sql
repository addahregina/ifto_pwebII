create table tb_produto (id long not null AUTO_INCREMENT, descricao varchar(50), valor double);

insert into tb_produto (descricao,valor) values ('Porsche',300);
insert into tb_produto (descricao,valor) values ('Ferrari',125);
insert into tb_produto (descricao,valor) values ('Maseratti',500);
insert into tb_produto (descricao,valor) values ('Austin',400);
